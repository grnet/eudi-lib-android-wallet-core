/*
 * Copyright (c) 2023-2025 European Commission
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Utility functions and helpers for OpenID4VP (OpenID for Verifiable Presentations) flows.
 *
 * This file provides methods for generating session transcripts, handling cryptographic operations,
 * converting between OpenID4VP and SIOP configurations, and constructing verifiable presentations
 * for both SD-JWT VC and MSO mdoc credential formats. It also includes helpers for algorithm
 * conversions and key binding JWT serialization.
 *
 * Functions in this file are intended for internal use within the wallet-core module.
 */

package eu.europa.ec.eudi.wallet.internal

import com.nimbusds.jose.JWEAlgorithm
import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.jwk.JWKSet
import com.upokecenter.cbor.CBORObject
import eu.europa.ec.eudi.iso18013.transfer.SessionTranscriptBytes
import eu.europa.ec.eudi.iso18013.transfer.internal.DocumentResponseGenerator
import eu.europa.ec.eudi.openid4vp.CoseAlgorithm
import eu.europa.ec.eudi.openid4vp.HashAlgorithm
import eu.europa.ec.eudi.openid4vp.OpenId4VPConfig
import eu.europa.ec.eudi.openid4vp.PreregisteredClient
import eu.europa.ec.eudi.openid4vp.ResolvedRequestObject
import eu.europa.ec.eudi.openid4vp.ResponseEncryptionConfiguration
import eu.europa.ec.eudi.openid4vp.ResponseMode
import eu.europa.ec.eudi.openid4vp.SupportedClientIdPrefix
import eu.europa.ec.eudi.openid4vp.SupportedTransactionDataType
import eu.europa.ec.eudi.openid4vp.TransactionData
import eu.europa.ec.eudi.openid4vp.VerifiablePresentation
import eu.europa.ec.eudi.openid4vp.VpFormatsSupported
import eu.europa.ec.eudi.wallet.document.DocumentManager
import eu.europa.ec.eudi.openid4vp.RegistrationCertificatePolicy
import eu.europa.ec.eudi.wallet.transfer.openId4vp.ClientIdScheme
import eu.europa.ec.eudi.wallet.transfer.openId4vp.EncryptionAlgorithm
import eu.europa.ec.eudi.wallet.transfer.openId4vp.EncryptionMethod
import eu.europa.ec.eudi.wallet.transfer.openId4vp.Format
import eu.europa.ec.eudi.wallet.transfer.openId4vp.OpenId4VpConfig
import eu.europa.ec.eudi.wallet.transfer.openId4vp.OpenId4VpReaderTrust
import eu.europa.ec.eudi.wallet.transfer.openId4vp.TransactionDataType
import eu.europa.ec.eudi.wallet.transfer.openId4vp.transactionData.TransactionDataDeviceSigned
import eu.europa.ec.eudi.wallet.transfer.openId4vp.transactionData.TransactionDataKeyBinding
import kotlinx.coroutines.withContext
import kotlinx.io.bytestring.decodeToString
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import org.multipaz.crypto.AsymmetricKey
import org.multipaz.mdoc.response.DeviceResponseGenerator
import org.multipaz.presentment.CredentialPresentmentSetOptionMemberMatch
import org.multipaz.presentment.PresentmentUnlockReason
import org.multipaz.presentment.TransactionData as ParsedTransactionData
import org.multipaz.request.JsonRequestedClaim
import org.multipaz.cbor.DataItem
import org.multipaz.mdoc.devicesigned.DeviceNamespaces
import org.multipaz.mdoc.devicesigned.buildDeviceNamespaces
import org.multipaz.request.MdocRequestedClaim
import org.multipaz.sdjwt.SdJwt
import org.multipaz.sdjwt.credential.SdJwtVcCredential
import org.multipaz.securearea.KeyUnlockData
import org.multipaz.util.Constants
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

private const val SHA_256_ALGORITHM = "SHA-256"

/**
 *  Utility to generate the session transcript for the OpenID4VP protocol.
 *
 *  SessionTranscript = [
 *    DeviceEngagementBytes,
 *    EReaderKeyBytes,
 *    Handover
 *  ]
 *
 *  DeviceEngagementBytes = null,
 *  EReaderKeyBytes = null
 *
 *  Handover = OID4VPHandover
 *
 *  OpenID4VPHandover = [
 *    "OpenID4VPHandover",      ; A fixed identifier for this handover type
 *    OpenID4VPHandoverInfoHash ; A cryptographic hash of OpenID4VPHandoverInfo
 *  ]
 *
 *  ; Contains the sha-256 hash of OpenID4VPHandoverInfoBytes
 *  OpenID4VPHandoverInfoHash = bstr
 *
 *  ; Contains the bytes of OpenID4VPHandoverInfo encoded as CBOR
 *  OpenID4VPHandoverInfoBytes = bstr .cbor OpenID4VPHandoverInfo
 *
 *  OpenID4VPHandoverInfo = [
 *    clientId,
 *    nonce,
 *    jwkThumbprint,
 *    responseUri
 *  ] ; Array containing handover parameters
 *
 *  clientId = tstr
 *  nonce = tstr
 *  jwkThumbprint = bstr
 *  responseUri = tstr
 */
internal fun generateSessionTranscript(
    clientId: String,
    nonce: String,
    jwkThumbprint: ByteArray?,
    responseOrRedirectUri: String
): SessionTranscriptBytes {

    val openID4VPHandover =
        generateOpenId4VpHandover(clientId, nonce, jwkThumbprint, responseOrRedirectUri)

    val sessionTranscriptBytes =
        CBORObject.NewArray().apply {
            Add(CBORObject.Null)
            Add(CBORObject.Null)
            Add(openID4VPHandover)
        }.EncodeToBytes()

    return sessionTranscriptBytes
}

/**
 * Generates the OpenID4VP handover CBOR object
 *
 * @param clientId The client identifier.
 * @param nonce The nonce value.
 * @param jwkThumbprint The JWK thumbprint as a byte array.
 * @param responseOrRedirectUri The response URI or redirect URI.
 * @return The CBOR object representing the OpenID4VP handover.
 */
internal fun generateOpenId4VpHandover(
    clientId: String,
    nonce: String,
    jwkThumbprint: ByteArray?,
    responseOrRedirectUri: String,
): CBORObject {

    val openID4VPHandoverInfoBytes = CBORObject.NewArray().apply {
        Add(clientId)
        Add(nonce)
        Add(jwkThumbprint ?: CBORObject.Null)
        Add(responseOrRedirectUri)
    }.EncodeToBytes()

    val openID4VPHandoverInfoHash = MessageDigest.getInstance(SHA_256_ALGORITHM)
        .digest(openID4VPHandoverInfoBytes)

    val openID4VPHandover = CBORObject.NewArray().apply {
        Add("OpenID4VPHandover")
        Add(openID4VPHandoverInfoHash)
    }

    return openID4VPHandover
}

/**
 * Generates the `OpenID4VPDCAPIHandover` CBOR object for OpenID4VP over the W3C Digital
 * Credentials API (OpenID4VP 1.0, §"Invocation via the Digital Credentials API"):
 *
 * ```
 * OpenID4VPDCAPIHandover = [
 *   "OpenID4VPDCAPIHandover",
 *   sha256( cbor([origin, nonce, jwkThumbprint]) )
 * ]
 * ```
 *
 * @param origin The verifier Origin, NOT prefixed with `origin:`.
 * @param nonce The request `nonce`.
 * @param jwkThumbprint The JWK SHA-256 thumbprint (RFC 7638) of the verifier's response
 *   encryption key for response mode `dc_api.jwt`; `null` (encoded as CBOR null) for `dc_api`.
 */
internal fun generateOpenId4VpDCAPIHandover(
    origin: String,
    nonce: String,
    jwkThumbprint: ByteArray?,
): CBORObject {

    val handoverInfoBytes = CBORObject.NewArray().apply {
        Add(origin)
        Add(nonce)
        Add(jwkThumbprint ?: CBORObject.Null)
    }.EncodeToBytes()

    val handoverInfoHash = MessageDigest.getInstance(SHA_256_ALGORITHM)
        .digest(handoverInfoBytes)

    return CBORObject.NewArray().apply {
        Add("OpenID4VPDCAPIHandover")
        Add(handoverInfoHash)
    }
}

/**
 * Generates the session transcript for OpenID4VP over the DC API:
 * `[ null, null, OpenID4VPDCAPIHandover ]`.
 */
internal fun generateDCAPISessionTranscript(
    origin: String,
    nonce: String,
    jwkThumbprint: ByteArray?,
): SessionTranscriptBytes {
    val handover = generateOpenId4VpDCAPIHandover(origin, nonce, jwkThumbprint)
    return CBORObject.NewArray().apply {
        Add(CBORObject.Null)
        Add(CBORObject.Null)
        Add(handover)
    }.EncodeToBytes()
}

/**
 * Generates a random nonce for a generic JARM (JWT Secured Authorization Response Mode) using a secure random generator.
 *
 * @return A URL-safe base64 encoded nonce string.
 */
internal fun generateJarmNonce(): String {
    val secureRandom = SecureRandom()
    val bytes = ByteArray(16)
    secureRandom.nextBytes(bytes)
    return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
}

internal fun makeOpenId4VPConfig(
    config: OpenId4VpConfig,
    trust: OpenId4VpReaderTrust,
    registrationCertificatePolicy: RegistrationCertificatePolicy? = null,
): OpenId4VPConfig {
    val supportedClientIdPrefixes = config.clientIdSchemes.map { clientIdScheme ->
        when (clientIdScheme) {
            is ClientIdScheme.Preregistered -> SupportedClientIdPrefix.Preregistered(
                clientIdScheme.preregisteredVerifiers.associate { verifier ->
                    verifier.clientId to PreregisteredClient(
                        clientId = verifier.clientId,
                        legalName = verifier.legalName,
                        jarConfig = verifier.jwkSet?.let { jwkSet ->
                            JWSAlgorithm.parse(verifier.jwsAlgorithm.joseAlgorithmIdentifier) to JWKSet.parse(jwkSet)
                        },
                    )
                }
            )

            ClientIdScheme.RedirectUri -> SupportedClientIdPrefix.RedirectUri
            ClientIdScheme.X509SanDns -> SupportedClientIdPrefix.X509SanDns(trust = trust)
            ClientIdScheme.X509Hash -> SupportedClientIdPrefix.X509Hash(trust = trust)
        }
    }
    return OpenId4VPConfig(
        issuer = OpenId4VPConfig.SelfIssued,
        responseEncryptionConfiguration = ResponseEncryptionConfiguration.Supported(
            supportedAlgorithms = config.encryptionAlgorithms.map { it.nimbus },
            supportedMethods = config.encryptionMethods.map { it.nimbus }
        ),
        vpFormatsSupported = config.formats.toVpFormats(),
        supportedClientIdPrefixes = supportedClientIdPrefixes,
        supportedTransactionDataTypes = config.transactionDataTypes.toSupportedTransactionDataTypes(),
        registrationCertificatePolicy = registrationCertificatePolicy
    )
}

/**
 * Extension function to get the session transcript bytes from a resolved OpenID4VP authorization request.
 *
 * @return The session transcript as a byte array.
 */
internal fun ResolvedRequestObject.getSessionTranscriptBytes(): SessionTranscriptBytes {
    val clientId = client.id.clientId
    val nonce = nonce
    val jwkThumbprint = responseEncryptionSpecification?.recipientKey?.computeThumbprint()?.decode()
    val responseOrRedirectUri = when (val mode = this.responseMode) {
        is ResponseMode.DirectPostJwt -> mode.responseURI.toString()
        is ResponseMode.DirectPost -> mode.responseURI.toString()
        is ResponseMode.Fragment -> mode.redirectUri.toString()
        is ResponseMode.FragmentJwt -> mode.redirectUri.toString()
        is ResponseMode.Query -> mode.redirectUri.toString()
        is ResponseMode.QueryJwt -> mode.redirectUri.toString()
        // DC API uses the OpenID4VPDCAPIHandover, not this URI-based handover;
        // the HTTP resolver path never yields these modes. DC API support is handled separately.
        ResponseMode.DCApi, ResponseMode.DCApiJwt ->
            error("DC API response mode is not supported for OpenID4VP HTTP session transcript generation")
    }
    val sessionTranscriptBytes = generateSessionTranscript(
        clientId = clientId,
        nonce = nonce,
        jwkThumbprint = jwkThumbprint,
        responseOrRedirectUri = responseOrRedirectUri
    )
    return sessionTranscriptBytes
}

/**
 * Session transcript for the DC API channel. For [ResponseMode.DCApi]/[ResponseMode.DCApiJwt]
 * it builds the [OpenID4VPDCAPIHandover]-based transcript bound to [origin], the request nonce,
 * and the verifier's response-encryption key thumbprint (null for `dc_api`). All HTTP response
 * modes delegate to the no-arg [getSessionTranscriptBytes].
 *
 * @param origin The verifier Origin from the DC API call (plain, NOT prefixed with `origin:`).
 */
internal fun ResolvedRequestObject.getSessionTranscriptBytes(origin: String): SessionTranscriptBytes =
    when (this.responseMode) {
        ResponseMode.DCApi, ResponseMode.DCApiJwt -> generateDCAPISessionTranscript(
            origin = origin,
            nonce = nonce,
            jwkThumbprint = responseEncryptionSpecification?.recipientKey?.computeThumbprint()?.decode()
        )

        else -> getSessionTranscriptBytes()
    }

/**
 * Converts the configured transaction data types to the types supported by the OpenID4VP library.
 *
 * Every type is advertised for SD-JWT VC with `sha-256`, which OpenID4VP requires all
 * implementations to support and uses as the default when a request does not state a hash
 * algorithm. The profile of Appendix B.3.3.1 binds any type, so every type can be presented.
 *
 * A type is advertised for mdoc only when it returns a data element of its own. Appendix B.2.1
 * defines no profile that binds a type which does not, so accepting one would leave the
 * presentation carrying nothing of the transaction it authorizes.
 */
internal fun List<TransactionDataType>.toSupportedTransactionDataTypes(): List<SupportedTransactionDataType> =
    flatMap { type ->
        val declared = eu.europa.ec.eudi.openid4vp.TransactionDataType(type.value)
        buildList {
            add(
                SupportedTransactionDataType.SdJwtVc(
                    type = declared,
                    hashAlgorithms = type.hashAlgorithms
                )
            )
            if (type.parser is TransactionDataDeviceSigned) {
                add(SupportedTransactionDataType.MsoMdoc(type = declared))
            }
        }
    }

/**
 * The hash algorithms with which the wallet can calculate transaction data hashes, by the name of
 * their message digest. OpenID4VP requires every implementation to support `sha-256` and uses it
 * when a request states no algorithm.
 */
internal val TRANSACTION_DATA_HASH_ALGORITHMS: Map<HashAlgorithm, String> = mapOf(
    HashAlgorithm.SHA_256 to SHA_256_ALGORITHM,
)

private fun HashAlgorithm.messageDigestName(): String =
    TRANSACTION_DATA_HASH_ALGORITHMS[this]
        ?: throw IllegalArgumentException("Unsupported transaction data hash algorithm '$name'")

/**
 * Calculates the Key Binding JWT claims that bind a presentation to the transaction data it
 * authorizes, as defined by the SD-JWT VC profile of OpenID4VP.
 *
 * Each hash is calculated over the transaction data string as it was received, which is not
 * base64url decoded first. `transaction_data_hashes_alg` names the algorithm used and is always
 * included.
 *
 * A transaction data type may define a claim of its own besides these, as OpenID4VP recommends in
 * Appendix B.3.3 and [TransactionDataKeyBinding] describes.
 *
 * @receiver the transaction data authorized by a single presentation
 * @return the claims to add to the Key Binding JWT, or an empty map when there is no transaction data
 * @throws IllegalArgumentException when the transaction data share no algorithm the wallet
 * supports, when a type cannot bind the transaction data it was given, or when a type defines a
 * claim that another type or the presentation itself already sets
 */
internal fun List<ParsedTransactionData<*>>.transactionDataKeyBindingClaims(): Map<String, JsonElement> {
    if (isEmpty()) return emptyMap()

    val requested = map { transactionData ->
        transactionData.hashAlgorithms?.mapNotNull { it.hashAlgorithmName }?.toSet()
            ?: setOf(HashAlgorithm.SHA_256.name)
    }
    val algorithm = requested.reduce { common, algorithms -> common intersect algorithms }
        .map { HashAlgorithm(it) }
        .firstOrNull { it in TRANSACTION_DATA_HASH_ALGORITHMS }
        ?: throw IllegalArgumentException(
            "Transaction data of a single presentation share no supported hash algorithm"
        )

    val digest = MessageDigest.getInstance(algorithm.messageDigestName())
    val encoder = Base64.getUrlEncoder().withoutPadding()
    val hashes = map { transactionData ->
        JsonPrimitive(encoder.encodeToString(digest.digest(transactionData.rawBytes.toByteArray())))
    }

    val claims = mutableMapOf<String, JsonElement>(
        OpenId4VPSpec.TRANSACTION_DATA_HASHES_ALG to JsonPrimitive(algorithm.name),
        OpenId4VPSpec.TRANSACTION_DATA_HASHES to JsonArray(hashes),
    )
    groupBy { it.type }.forEach { (type, ofType) ->
        if (type !is TransactionDataKeyBinding) return@forEach
        type.keyBindingClaims(ofType).forEach { (claim, value) ->
            require(claim !in KEY_BINDING_JWT_CLAIMS) {
                "The transaction data type '${type.identifier}' cannot define the Key Binding JWT " +
                    "claim '$claim', which the presentation sets itself"
            }
            require(claims.put(claim, value) == null) {
                "The transaction data of a single presentation define the Key Binding JWT claim " +
                    "'$claim' more than once"
            }
        }
    }
    return claims
}

/**
 * Calculates the `DeviceSigned` data elements that bind a presentation to the transaction data it
 * authorizes, as defined by OpenID4VP Appendix B.2.1.
 *
 * Each type that returns a data element of its own contributes it, in the name space it declares.
 * A type that does not is not bound: unlike the SD-JWT VC profile of Appendix B.3.3.1, mdoc has no
 * profile that binds a type which defines no element of its own.
 *
 * @throws IllegalArgumentException when two types return the same data element of the same name
 * space, or when a type cannot bind its transaction data
 */
internal fun List<ParsedTransactionData<*>>.deviceSignedNamespaces(): DeviceNamespaces {
    if (isEmpty()) return buildDeviceNamespaces {}

    val elements = mutableMapOf<String, MutableMap<String, DataItem>>()
    groupBy { it.type }.forEach { (type, ofType) ->
        if (type !is TransactionDataDeviceSigned) return@forEach
        val nameSpace = elements.getOrPut(type.nameSpace) { mutableMapOf() }
        type.deviceSignedElements(ofType).forEach { (element, value) ->
            require(nameSpace.put(element, value) == null) {
                "The transaction data of a single presentation return the data element " +
                    "'$element' of name space '${type.nameSpace}' more than once"
            }
        }
    }
    return DeviceNamespaces(elements)
}

/**
 * The claims the Key Binding JWT itself carries. They are written before the transaction data
 * claims, so a transaction data type that used one of these names would replace it unnoticed.
 */
private val KEY_BINDING_JWT_CLAIMS: Set<String> =
    setOf("sd_hash", "nonce", "aud", "iat", "exp")

private object OpenId4VPSpec {
    const val TRANSACTION_DATA_HASHES: String = "transaction_data_hashes"
    const val TRANSACTION_DATA_HASHES_ALG: String = "transaction_data_hashes_alg"
}

/**
 * Converts a list of [Format]s to [VpFormats] for use in VP configuration.
 *
 * @receiver List of credential formats.
 * @return The corresponding [VpFormats] object.
 */
internal fun List<Format>.toVpFormats(): VpFormatsSupported {

    val msoMdocVpFormat = filterIsInstance<Format.MsoMdoc>()
        .firstOrNull()
        ?.let { spec ->
            VpFormatsSupported.MsoMdoc(
                issuerAuthAlgorithms = spec.issuerAuthAlgorithms.map { CoseAlgorithm(it.coseAlgorithmIdentifier!!) },
                deviceAuthAlgorithms = spec.deviceAuthAlgorithms.map { CoseAlgorithm(it.coseAlgorithmIdentifier!!) }
            )
        }


    val sdJwtVcVpFormat = filterIsInstance<Format.SdJwtVc>()
        .firstOrNull()
        ?.let { spec ->
            VpFormatsSupported.SdJwtVc(
                sdJwtAlgorithms = spec.sdJwtAlgorithms.map { JWSAlgorithm.parse(it.joseAlgorithmIdentifier!!) },
                kbJwtAlgorithms = spec.kbJwtAlgorithms.map { JWSAlgorithm.parse(it.joseAlgorithmIdentifier!!) }
            )
        }

    return VpFormatsSupported(
        sdJwtVc = sdJwtVcVpFormat,
        msoMdoc = msoMdocVpFormat
    )
}

/**
 * Extension property to convert an [EncryptionAlgorithm] to Nimbus [JWEAlgorithm].
 */
internal val EncryptionAlgorithm.nimbus: JWEAlgorithm
    get() = when (this) {
        EncryptionAlgorithm.ECDH_ES -> JWEAlgorithm.ECDH_ES
        EncryptionAlgorithm.ECDH_ES_A128KW -> JWEAlgorithm.ECDH_ES_A128KW
        EncryptionAlgorithm.ECDH_ES_A192KW -> JWEAlgorithm.ECDH_ES_A192KW
        EncryptionAlgorithm.ECDH_ES_A256KW -> JWEAlgorithm.ECDH_ES_A256KW
    }

internal val EncryptionMethod.nimbus: com.nimbusds.jose.EncryptionMethod
    get() = when (this) {
        EncryptionMethod.A128CBC_HS256 -> com.nimbusds.jose.EncryptionMethod.A128CBC_HS256
        EncryptionMethod.A192CBC_HS384 -> com.nimbusds.jose.EncryptionMethod.A192CBC_HS384
        EncryptionMethod.A256CBC_HS512 -> com.nimbusds.jose.EncryptionMethod.A256CBC_HS512
        EncryptionMethod.A128GCM -> com.nimbusds.jose.EncryptionMethod.A128GCM
        EncryptionMethod.A192GCM -> com.nimbusds.jose.EncryptionMethod.A192GCM
        EncryptionMethod.A256GCM -> com.nimbusds.jose.EncryptionMethod.A256GCM
        EncryptionMethod.A128CBC_HS256_DEPRECATED -> com.nimbusds.jose.EncryptionMethod.A128CBC_HS256_DEPRECATED
        EncryptionMethod.A256CBC_HS512_DEPRECATED -> com.nimbusds.jose.EncryptionMethod.A256CBC_HS512_DEPRECATED
        EncryptionMethod.XC20P -> com.nimbusds.jose.EncryptionMethod.XC20P
    }

/**
 * Builds a verifiable presentation for an SD-JWT VC credential from a single match.
 *
 * Each request path from [JsonRequestedClaim.claimPath] is matched against the SD-JWT
 * disclosure paths through [pathMatches], honouring OpenID4VP §7.1 semantics for
 * string keys, integer array indices, and `null` wildcards. Parent disclosures
 * required to reconstruct a selected child are pulled in automatically.
 *
 * Key Binding JWT is emitted whenever the issuer-signed JWT carries a `cnf` claim,
 * regardless of the verifier's `require_cryptographic_holder_binding` flag.
 * Verifiers that did not request the proof can ignore it.
 * The flag is honoured at match time in [DcqlRequestProcessor], which
 * filters out credentials lacking `cnf` when the verifier requires holder binding —
 * so the bare-SD-JWT branch below runs only when the verifier explicitly accepts
 * presentations without holder binding.
 *
 * Empty `match.claims` corresponds to OpenID4VP §6.4.1 "claims=null" semantics
 * (mandatory disclosure only).
 *
 * [transactionData] holds the transaction data this presentation authorizes. When it is not empty,
 * the Key Binding JWT also carries the transaction data hashes.
 */
internal suspend fun verifiablePresentationForSdJwtVc(
    resolvedRequestObject: ResolvedRequestObject,
    match: CredentialPresentmentSetOptionMemberMatch,
    documentManager: DocumentManager,
    keyUnlockData: KeyUnlockData?,
    audience: String? = null,
    transactionData: List<ParsedTransactionData<*>> = emptyList()
): VerifiablePresentation.Generic {
    val document = match.credential.requireIssuedDocument(documentManager)
    return document.consumingCredential {
        val sdJwtVcCredential = this as? SdJwtVcCredential
            ?: throw IllegalStateException(
                "Credential ${this.identifier} is not an SD-JWT VC credential"
            )
        val sdJwt = SdJwt.fromCompactSerialization(
            sdJwtVcCredential.issuerProvidedData.decodeToString()
        )

        val requestPaths = match.claims.keys
            .filterIsInstance<JsonRequestedClaim>()
            .map { it.claimPath }

        val filteredSdJwt = sdJwt.filter { emittedPath, _ ->
            requestPaths.any { requestPath -> pathMatches(requestPath, emittedPath) }
        }

        val serialized = if (filteredSdJwt.kbKey != null) {
            val signingKey = AsymmetricKey.anonymous(
                secureArea = this.secureArea,
                alias = this.alias,
                unlockReason = PresentmentUnlockReason(this)
            )
            val transactionDataClaims = transactionData.transactionDataKeyBindingClaims()
            withContext(keyUnlockData.asProvider()) {
                filteredSdJwt.present(
                    signingKey = signingKey,
                    nonce = resolvedRequestObject.nonce,
                    audience = audience ?: resolvedRequestObject.client.id.clientId
                ) {
                    transactionDataClaims.forEach { (claim, value) -> put(claim, value) }
                }
            }.compactSerialization
        } else {
            filteredSdJwt.compactSerialization
        }

        VerifiablePresentation.Generic(serialized)
    }.getOrThrow()
}

/**
 * Builds a verifiable presentation for an MSO mdoc credential from a single
 * [CredentialPresentmentSetOptionMemberMatch].
 *
 * Produces a single-document `DeviceResponse` (status OK) bound to [sessionTranscript],
 * encoded as base64url for transport in OpenID4VP `vp_token`. Disclosed elements are
 * taken from the match's [MdocRequestedClaim] keys, grouped by namespace; an empty claim
 * set yields a minimal response.
 */
internal suspend fun verifiablePresentationForMsoMdoc(
    match: CredentialPresentmentSetOptionMemberMatch,
    documentManager: DocumentManager,
    sessionTranscript: ByteArray,
    keyUnlockData: KeyUnlockData?,
    transactionData: List<ParsedTransactionData<*>> = emptyList()
): VerifiablePresentation.Generic {
    val document = match.credential.requireIssuedDocument(documentManager)

    val elements: Map<String, List<String>> = match.claims.keys
        .filterIsInstance<MdocRequestedClaim>()
        .groupBy { it.namespaceName }
        .mapValues { (_, claims) -> claims.map { it.dataElementName } }

    val encodedDocument = DocumentResponseGenerator.generate(
        document = document,
        transcript = sessionTranscript,
        elements = elements,
        keyUnlockData = keyUnlockData,
        deviceNamespaces = transactionData.deviceSignedNamespaces()
    )
    val deviceResponseBytes = DeviceResponseGenerator(Constants.DEVICE_RESPONSE_STATUS_OK)
        .addDocument(encodedDocument)
        .generate()

    return VerifiablePresentation.Generic(
        value = Base64.getUrlEncoder().withoutPadding().encodeToString(deviceResponseBytes)
    )
}

/**
 * Matches a DCQL claim path against an SD-JWT disclosure path emitted during the
 * filter pass. Honours OpenID4VP §7.1:
 *
 *  - String key matches the same string key.
 *  - Integer index matches the same integer index.
 *  - [JsonNull] wildcard matches any integer index.
 *
 * Returns true iff every position the two paths share matches element-by-element.
 * Emitted paths are accepted in three positions relative to the request:
 *
 *  - Equal → exact match.
 *  - Longer than the request → descendant disclosure; releases every field of
 *    the targeted node (request `["addresses", 0]` also releases
 *    `["addresses", 0, "city"]`).
 *  - Shorter than the request → ancestor disclosure; required because SD-JWT
 *    array-element disclosures cannot be reconstructed by the verifier without
 *    their parent-array disclosure. Ancestor envelopes carry only child digests
 *    and no extra data beyond what the request already authorises.
 */
private fun pathMatches(request: JsonArray, emittedPath: JsonArray): Boolean {
    val requestElements = request.toList()
    val emittedElements = emittedPath.toList()
    val common = minOf(requestElements.size, emittedElements.size)
    for (i in 0 until common) {
        if (!elementMatches(requestElements[i], emittedElements[i])) return false
    }
    return true
}

private fun elementMatches(request: JsonElement, emitted: JsonElement): Boolean =
    when (request) {
        is JsonNull -> emitted is JsonPrimitive && !emitted.isString
        is JsonPrimitive if request.isString ->
            emitted is JsonPrimitive && emitted.isString && request.content == emitted.content

        is JsonPrimitive if !request.isString ->
            emitted is JsonPrimitive && !emitted.isString && request.content == emitted.content

        else -> false
    }