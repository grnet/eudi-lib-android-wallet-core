/*
 * Copyright (c) 2024-2025 European Commission
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.europa.ec.eudi.wallet.issue.openid4vci

import android.content.Context
import eu.europa.ec.eudi.openid4vci.CIAuthorizationServerMetadata
import eu.europa.ec.eudi.openid4vci.ClientAuthentication
import eu.europa.ec.eudi.openid4vci.CredentialConfigurationIdentifier
import eu.europa.ec.eudi.openid4vci.CredentialIssuerId
import eu.europa.ec.eudi.openid4vci.CredentialIssuerMetadata
import eu.europa.ec.eudi.openid4vci.CredentialIssuerMetadataResolver
import eu.europa.ec.eudi.openid4vci.CredentialOffer
import eu.europa.ec.eudi.openid4vci.CredentialOfferRequestError
import eu.europa.ec.eudi.openid4vci.CredentialOfferRequestException
import eu.europa.ec.eudi.openid4vci.Issuer
import eu.europa.ec.eudi.openid4vci.IssuerMetadataPolicy
import eu.europa.ec.eudi.openid4vci.OpenId4VCIConfig
import eu.europa.ec.eudi.openid4vci.DPoPUsage
import eu.europa.ec.eudi.openid4vci.HttpsUrl
import eu.europa.ec.eudi.openid4vci.JwsAlgorithm
import eu.europa.ec.eudi.openid4vci.ParUsage
import eu.europa.ec.eudi.openid4vci.ProofsConfig
import eu.europa.ec.eudi.openid4vci.Signer
import eu.europa.ec.eudi.openid4vci.clientAttestationPOPJWSAlgs
import eu.europa.ec.eudi.wallet.document.format.DocumentFormat
import eu.europa.ec.eudi.wallet.document.format.MsoMdocFormat
import eu.europa.ec.eudi.wallet.document.format.SdJwtVcFormat
import eu.europa.ec.eudi.wallet.issue.openid4vci.CredentialConfigurationFilter.Companion.DocTypeFilter
import eu.europa.ec.eudi.wallet.issue.openid4vci.CredentialConfigurationFilter.Companion.VctFilter
import eu.europa.ec.eudi.wallet.issue.openid4vci.OpenId4VciManager.Companion.TAG
import eu.europa.ec.eudi.wallet.issue.openid4vci.OpenId4VciManager.IssuanceProofProfile.ProofType as IssuanceProofType
import eu.europa.ec.eudi.wallet.issue.openid4vci.dpop.DPopConfig
import eu.europa.ec.eudi.wallet.issue.openid4vci.dpop.SecureAreaDpopSigner
import eu.europa.ec.eudi.wallet.internal.d
import eu.europa.ec.eudi.wallet.internal.e
import eu.europa.ec.eudi.wallet.internal.i
import eu.europa.ec.eudi.wallet.logging.Logger
import eu.europa.ec.eudi.wallet.provider.WalletInstanceAttestationProvider
import eu.europa.ec.eudi.wallet.provider.WalletKeyManager
import eu.europa.ec.eudi.wallet.registration.issuer.IssuerRegistrationResolver
import eu.europa.ec.eudi.wallet.registration.issuer.issuerRegistrationCertificatePolicy
import eu.europa.ec.eudi.wallet.registration.RegistrationCertificateResult
import io.ktor.client.HttpClient
import org.jetbrains.annotations.VisibleForTesting
import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.jwk.JWK
import org.multipaz.crypto.Algorithm
import java.net.URI
import eu.europa.ec.eudi.openid4vci.DPoPConfig as VciDPoPConfig
import eu.europa.ec.eudi.openid4vci.ProvisionDPoPSigner as VciProvisionDPoPSigner

/**
 * An [Issuer] together with the outcome of validating the credential issuer's registration
 * certificate for this issuance.
 *
 * @property issuer the created issuer
 * @property issuerRegistration the registration outcome to present, or null when the certificate was
 * not evaluated and the caller is to evaluate it
 */
internal data class IssuerCreation(
    val issuer: Issuer,
    val issuerRegistration: RegistrationCertificateResult?,
)

/**
 * Creates an [Issuer] from the given [Offer].
 */
internal class IssuerCreator(
    private val context: Context,
    private val config: OpenId4VciManager.Config,
    private val ktorHttpClientFactory: () -> HttpClient,
    private val walletInstanceAttestationProvider: WalletInstanceAttestationProvider?,
    private val walletAttestationKeyManager: WalletKeyManager,
    private val logger: Logger?,
    private val issuerMetadataPolicy: IssuerMetadataPolicy = IssuerMetadataPolicy.IgnoreSigned,
    private val issuerRegistrationEnabled: Boolean = false,
    private val issuerRegistration: IssuerRegistrationResolver? = null,
) {

    internal var clientAttestationPopKeyId: String? = null
        private set

    internal var dpopKeyAlias: String? = null
        private set

    internal lateinit var clientAuthentication: ClientAuthentication
        private set

    /**
     * Creates an [Issuer] from the given [Offer]. A registration outcome already carried by the offer
     * is reused, so the certificate is not evaluated again.
     * @param offer The [Offer].
     * @return The [Issuer] and the registration outcome.
     */
    suspend fun createIssuer(offer: Offer): IssuerCreation =
        doCreateIssuer(offer.credentialOffer, offer.issuerRegistration)

    /**
     * Creates an [Issuer] from the given [CredentialConfigurationIdentifier]s.
     * @param issuerUrl The issuer URL.
     * @param credentialConfigurationIdentifiers The list of [CredentialConfigurationIdentifier]s.
     * @param existingDpopKeyAlias Optional alias of an existing DPoP key to reuse (for re-issuance).
     * @return The [Issuer] and the registration outcome.
     */
    suspend fun createIssuer(
        issuerUrl: String,
        credentialConfigurationIdentifiers: List<CredentialConfigurationIdentifier>,
        existingDpopKeyAlias: String? = null,
    ): IssuerCreation = doCreateIssuer(
        CredentialIssuerId(issuerUrl).getOrThrow(),
        credentialConfigurationIdentifiers,
        existingDpopKeyAlias,
    )

    /**
     * Creates an [Issuer] from the given [DocumentFormat].
     * This method finds a suitable credential configuration based on the document format and creates an issuer.
     *
     * @param documentFormat The format of the document for which to create an issuer.
     * @return The [Issuer] supporting the given document format, and the registration outcome.
     * @throws IllegalStateException if no suitable configuration is found for the document format.
     */
    suspend fun createIssuer(issuerUrl: String, documentFormat: DocumentFormat): IssuerCreation {
        val formatFilter = when (documentFormat) {
            is MsoMdocFormat -> DocTypeFilter(documentFormat.docType)
            is SdJwtVcFormat -> VctFilter(documentFormat.vct)
        }
        val credentialIssuerId = CredentialIssuerId(issuerUrl).getOrThrow()
        val issuerMetadata = ktorHttpClientFactory().use {
            CredentialIssuerMetadataResolver(it).resolve(credentialIssuerId, issuerMetadataPolicy)
        }.getOrThrow()

        val configurationId = issuerMetadata.credentialConfigurationsSupported
            .filterValues { conf -> formatFilter(conf) }
            .firstNotNullOfOrNull { (confId, _) -> confId }
            ?: throw IllegalStateException("No suitable configuration found")

        return doCreateIssuer(credentialIssuerId, listOf(configurationId))
    }


    private suspend fun doCreateIssuer(
        credentialOffer: CredentialOffer,
        resolvedRegistration: RegistrationCertificateResult? = null,
    ): IssuerCreation {
        var evaluatedRegistration: RegistrationCertificateResult? = null
        val issuer = Issuer.make(
            config = config.toOpenId4VCIConfig(
                credentialOffer.authorizationServerMetadata,
                credentialIssuerMetadata = credentialOffer.credentialIssuerMetadata,
                resolvedRegistration = resolvedRegistration,
                onRegistrationEvaluated = { evaluatedRegistration = it },
            ),
            credentialOffer = credentialOffer,
            httpClient = ktorHttpClientFactory()
        ).getOrThrow().first
        return IssuerCreation(issuer, resolvedRegistration ?: evaluatedRegistration)
    }

    /**
     * Creates an [Issuer] for wallet-initiated issuance.
     *
     * Performs the two steps of [Issuer.makeWalletInitiated] separately: the credential offer is
     * resolved first, which fetches the credential issuer and authorization server metadata once,
     * and the client authentication is then built from the resolved authorization server metadata
     * before [Issuer.make] is called.
     *
     * The http client is closed if creation fails; otherwise the returned issuer keeps using it.
     * Metadata resolution errors are rethrown as reported by the metadata resolvers, see
     * [metadataResolutionReasonOrSelf].
     *
     * @param credentialIssuerId the credential issuer
     * @param credentialConfigurationIdentifiers the credential configurations to request
     * @param existingDpopKeyAlias alias of an existing DPoP key to reuse (for re-issuance)
     * @return the [Issuer] and the registration outcome evaluated by [Issuer.make]
     */
    private suspend fun doCreateIssuer(
        credentialIssuerId: CredentialIssuerId,
        credentialConfigurationIdentifiers: List<CredentialConfigurationIdentifier>,
        existingDpopKeyAlias: String? = null,
    ): IssuerCreation {
        val httpClient = ktorHttpClientFactory()
        return try {
            var evaluatedRegistration: RegistrationCertificateResult? = null
            val resolutionConfig = config.toOpenId4VCIConfig(
                authorizationServerMetadata = null,
                existingDpopKeyAlias = existingDpopKeyAlias,
                onRegistrationEvaluated = { evaluatedRegistration = it },
            )
            val credentialOffer = CredentialOffer.walletInitiated(
                httpClient = httpClient,
                config = resolutionConfig,
                credentialIssuerId = credentialIssuerId,
                credentialConfigurationIdentifiers = credentialConfigurationIdentifiers,
            ).getOrElse { throw it.metadataResolutionReasonOrSelf() }
            val auth = credentialOffer.authorizationServerMetadata.toClientAuthentication().getOrThrow()
            clientAuthentication = auth
            val issuer = Issuer.make(
                config = resolutionConfig.copy(clientAuthentication = auth),
                credentialOffer = credentialOffer,
                httpClient = httpClient,
            ).getOrThrow().first
            IssuerCreation(issuer, evaluatedRegistration)
        } catch (e: Throwable) {
            httpClient.close()
            logger?.e(TAG, "Failed to create wallet-initiated issuer", e)
            throw e
        }
    }

    private suspend fun CIAuthorizationServerMetadata.toClientAuthentication(): Result<ClientAuthentication> =
        runCatching {
            val issuerUrl = this.issuer.value
            when (val type = config.clientAuthenticationType) {
                is OpenId4VciManager.ClientAuthenticationType.None -> ClientAuthentication.None(type.clientId)
                is OpenId4VciManager.ClientAuthenticationType.AttestationBased -> {
                    val walletAttestationsProvider = checkNotNull(walletInstanceAttestationProvider) {
                        "WalletInstanceAttestationProvider is required for attestation-based client authentication"
                    }
                    val clientAttestationPOPJWSAlgs = clientAttestationPOPJWSAlgs
                        .takeUnless { it.isNullOrEmpty() }
                        ?: throw IllegalStateException(
                            "Client attestation based authentication is not supported by the authorization server at ${this.authorizationEndpointURI}"
                        )
                    val supportedAlgorithms = clientAttestationPOPJWSAlgs.map { a ->
                        Algorithm.fromJoseAlgorithmIdentifier(a.name)
                    }
                    walletAttestationKeyManager
                        .getOrCreateWalletAttestationKey(issuerUrl, supportedAlgorithms)
                        .map {
                            clientAttestationPopKeyId = it.keyInfo.alias
                            with(it) {
                                walletAttestationsProvider.toClientAuthentication(type.clientId).getOrThrow()
                            }
                        }.getOrThrow()
                }
            }
        }

    /**
     * Converts the [OpenId4VciManager.Config] to [OpenId4VCIConfig].
     * @receiver The [OpenId4VciManager.Config].
     * @param authorizationServerMetadata the metadata the client authentication is built from. When
     * null, the client authentication is a placeholder: the config can only be used to resolve a
     * credential offer, which does not read it, and the caller replaces it before [Issuer.make].
     * @return The [OpenId4VCIConfig].
     */
    @VisibleForTesting
    internal suspend fun OpenId4VciManager.Config.toOpenId4VCIConfig(
        authorizationServerMetadata: CIAuthorizationServerMetadata?,
        existingDpopKeyAlias: String? = null,
        credentialIssuerMetadata: CredentialIssuerMetadata? = null,
        resolvedRegistration: RegistrationCertificateResult? = null,
        onRegistrationEvaluated: (RegistrationCertificateResult) -> Unit = {},
    ): OpenId4VCIConfig {
        val auth = when (authorizationServerMetadata) {
            null -> ClientAuthentication.None(
                when (val type = clientAuthenticationType) {
                    is OpenId4VciManager.ClientAuthenticationType.None -> type.clientId
                    is OpenId4VciManager.ClientAuthenticationType.AttestationBased -> type.clientId
                }
            )
            else -> authorizationServerMetadata.toClientAuthentication().getOrThrow().also {
                clientAuthentication = it
            }
        }
        // Resolve DPoP usage
        val dPoPUsage = when (dpopConfig) {
            DPopConfig.Disabled -> DPoPUsage.Never

            DPopConfig.Default, is DPopConfig.Custom -> {
                val resolvedConfig = when (dpopConfig) {
                    DPopConfig.Default -> DPopConfig.Default.make(context)
                    is DPopConfig.Custom -> dpopConfig
                    else -> error("unreachable")
                }

                val signingAlg = resolvedConfig.secureArea.supportedAlgorithms
                    .firstOrNull { it.isSigning && it.joseAlgorithmIdentifier != null }
                    ?: throw IllegalStateException("No signing algorithm available for DPoP")

                val provisionDPoPSigner = if (existingDpopKeyAlias != null) {
                    // Re-issuance: reuse existing DPoP key bound to the access token
                    object : VciProvisionDPoPSigner {
                        override val popAlgorithm = JwsAlgorithm(signingAlg.joseAlgorithmIdentifier!!)
                        override suspend fun invoke(authorizationServer: HttpsUrl): Signer<JWK> {
                            return SecureAreaDpopSigner.fromExistingKey(
                                resolvedConfig, existingDpopKeyAlias, logger
                            ).also {
                                dpopKeyAlias = it.keyInfo.alias
                            }
                        }
                    }
                } else {
                    // Normal issuance: create new DPoP key
                    object : VciProvisionDPoPSigner {
                        override val popAlgorithm = JwsAlgorithm(signingAlg.joseAlgorithmIdentifier!!)
                        override suspend fun invoke(authorizationServer: HttpsUrl): Signer<JWK> {
                            return SecureAreaDpopSigner(
                                resolvedConfig, listOf(signingAlg), logger
                            ).also {
                                dpopKeyAlias = it.keyInfo.alias
                            }
                        }
                    }
                }

                DPoPUsage.IfSupported(VciDPoPConfig(provisionDPoPSigner))
            }
        }

        if (issuerRegistrationEnabled && issuerMetadataPolicy !is IssuerMetadataPolicy.RequireSigned) {
            logger?.i(
                TAG,
                "issuer registration validation is enabled but signed issuer metadata is not " +
                    "configured (configureIssuerTrust { requireSignedMetadata() }); skipping it.",
            )
        }
        if (issuerRegistrationEnabled &&
            issuerMetadataPolicy is IssuerMetadataPolicy.RequireSigned &&
            issuerRegistration == null
        ) {
            logger?.i(
                TAG,
                "issuer registration validation is enabled but no trust is available for the " +
                    "registration certificate signer chain (needs configureEtsiTrust or " +
                    "configureIssuerRegistrationTrust); skipping it.",
            )
        }

        val registrationCertificatePolicy = issuerRegistration
            ?.takeIf { issuerMetadataPolicy is IssuerMetadataPolicy.RequireSigned }
            ?.let { resolver ->
                issuerRegistrationCertificatePolicy(
                    resolver = resolver,
                    resolvedRegistration = resolvedRegistration,
                    onEvaluated = onRegistrationEvaluated,
                    logger = logger,
                )
            }

        return OpenId4VCIConfig(
            clientAuthentication = auth,
            authFlowRedirectionURI = URI.create(authFlowRedirectionURI),
            encryptionSupportConfig = responseEncryptionConfig,
            supportedCredentialReusePolicies = supportedCredentialReusePolicies,
            dPoPUsage = dPoPUsage,
            parUsage = when (parUsage) {
                OpenId4VciManager.Config.ParUsage.IF_SUPPORTED -> ParUsage.IfSupported()
                OpenId4VciManager.Config.ParUsage.REQUIRED -> ParUsage.Required()
                OpenId4VciManager.Config.ParUsage.NEVER -> ParUsage.Never
                else -> ParUsage.IfSupported()
            },
            proofs = issuanceProofProfile.toProofsConfig(),
            issuerMetadataPolicy = issuerMetadataPolicy,
            registrationCertificatePolicy = registrationCertificatePolicy,
        )
    }
}

/**
 * Unwraps the credential issuer and authorization server metadata resolution errors that
 * [CredentialOffer.walletInitiated] wraps in a [CredentialOfferRequestException], which carries
 * neither a message nor a cause. The unwrapped errors are the ones [Issuer.metaData] throws, so
 * callers and the transaction log see the same failure as when the metadata was fetched up front.
 * Any other error is returned unchanged.
 */
private fun Throwable.metadataResolutionReasonOrSelf(): Throwable =
    when (val error = (this as? CredentialOfferRequestException)?.error) {
        is CredentialOfferRequestError.UnableToResolveCredentialIssuerMetadata -> error.reason
        is CredentialOfferRequestError.UnableToResolveAuthorizationServerMetadata -> error.reason
        else -> this
    }

private fun OpenId4VciManager.IssuanceProofProfile.toProofsConfig(): ProofsConfig {
    val byType = preferenceOrder.associateBy { it.proofType }
    return ProofsConfig(
        isNoProofSupported = IssuanceProofType.NO_PROOF in byType,
        jwtProofWithKeyAttestation = byType[IssuanceProofType.JWT_WITH_KEY_ATTESTATION]
            ?.algorithms?.mapToJWSAlgorithms()?.let { ProofsConfig.SupportedJwtProof(it) },
        attestationProof = byType[IssuanceProofType.ATTESTATION]
            ?.algorithms?.mapToJWSAlgorithms()?.let { ProofsConfig.SupportedAttestationProof(it) },
        jwtProofsWithoutKeyAttestation = byType[IssuanceProofType.JWT_WITHOUT_KEY_ATTESTATION]
            ?.algorithms?.mapToJWSAlgorithms()?.let { ProofsConfig.SupportedJwtProof(it) },
    )
}

private fun Set<Algorithm>.mapToJWSAlgorithms(): Set<JWSAlgorithm> =
    mapNotNull { it.joseAlgorithmIdentifier }
        .map { JWSAlgorithm.parse(it) }
        .toSet()