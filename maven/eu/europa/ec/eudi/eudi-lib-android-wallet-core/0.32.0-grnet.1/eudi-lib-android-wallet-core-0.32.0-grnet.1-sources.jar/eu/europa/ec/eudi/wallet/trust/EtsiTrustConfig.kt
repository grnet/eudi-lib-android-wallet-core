/*
 * Copyright (c) 2023-2026 European Commission
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.europa.ec.eudi.wallet.trust

import eu.europa.ec.eudi.etsi119602.datamodel.Uri
import eu.europa.ec.eudi.etsi119602.consultation.LoadLoTEAndPointers
import eu.europa.ec.eudi.etsi119602.consultation.VerifyJwtSignature
import eu.europa.ec.eudi.etsi1196x2.consultation.AttestationClassifications
import eu.europa.ec.eudi.etsi1196x2.consultation.SupportedLists
import java.security.cert.X509Certificate
import kotlin.time.Duration
import kotlin.time.Duration.Companion.hours
import kotlin.time.Duration.Companion.minutes

/**
 * Configuration for the ETSI LoTE (List of Trusted Entities) trust infrastructure.
 *
 * This centralizes the LoTE pipeline parameters so that the core can build the
 * [eu.europa.ec.eudi.etsi1196x2.consultation.IsChainTrustedForEUDIW] trust source
 * internally, eliminating the need for consumers to construct the ETSI library
 * plumbing themselves.
 *
 * @property loteLocations the LoTE download locations (e.g., PID, PubEAA, WRPAC provider URLs)
 * @property classifications attestation classifications mapping credential types to verification contexts
 * @property fileCacheExpiration how long downloaded LoTE files are cached on disk (default: 24 hours)
 * @property cacheTtl how long the in-memory trust anchor cache is valid (default: 20 minutes)
 * @property relaxCertificateProfiles whether to strip end-entity profile constraints (for DEV/testing)
 * @property pkixRevocationPolicy PKIX revocation checking policy for certificate chain validation (default: CRLPriority)
 * @property customJwtSignatureVerifier optional custom JWT signature verifier for LoTE JWTs;
 *   when null, the core uses its built-in [LoteJwtVerifier]
 * @property loteConstraints controls whether additional LoTE pointers are followed
 * @property loteSignerTrustAnchors the trust anchors of the LoTE signers, used by the built-in [LoteJwtVerifier]
 */
data class EtsiTrustConfig(
    val loteLocations: SupportedLists<Uri>,
    val classifications: AttestationClassifications,
    val fileCacheExpiration: Duration = DEFAULT_FILE_CACHE_EXPIRATION,
    val cacheTtl: Duration = DEFAULT_CACHE_TTL,
    val relaxCertificateProfiles: Boolean = false,
    val pkixRevocationPolicy: PkixRevocationPolicy = PkixRevocationPolicy.CRLPriority,
    val customJwtSignatureVerifier: VerifyJwtSignature? = null,
    val loteConstraints: LoadLoTEAndPointers.Constraints = LoadLoTEAndPointers.Constraints.DoNotLoadOtherPointers,
    val loteSignerTrustAnchors: List<X509Certificate> = emptyList()
) {
    companion object {
        val DEFAULT_FILE_CACHE_EXPIRATION: Duration = 24.hours
        val DEFAULT_CACHE_TTL: Duration = 20.minutes
    }
}

/**
 * DSL builder for constructing an [EtsiTrustConfig].
 *
 * [loteLocations], [classifications] and [loteSignerTrustAnchors] are required; [loteSignerTrustAnchors]
 * is not needed when [jwtSignatureVerifier] is set. All other settings have sensible defaults.
 *
 * Example:
 * ```
 * configureEtsiTrust {
 *     loteLocations(SupportedLists(
 *         pidProviders = Uri("https://trustedlist.../PIDProviders.jwt"),
 *         wrpacProviders = Uri("https://trustedlist.../WRPACProviders.jwt"),
 *         wrprcProviders = Uri("https://trustedlist.../WRPRCProviders.jwt"),
 *     ))
 *     classifications(AttestationClassifications(
 *         pids = AttestationIdentifierPredicate.any(setOf(
 *             AttestationIdentifier.MDoc("eu.europa.ec.eudi.pid.1"),
 *         )),
 *     ))
 *     loteSignerTrustAnchors(loteSignerCertificate)
 *     // Optional:
 *     relaxCertificateProfiles()
 *     fileCacheExpiration(12.hours)
 *     cacheTtl(10.minutes)
 * }
 * ```
 */
class EtsiTrustConfigBuilder {

    private var loteLocations: SupportedLists<Uri>? = null
    private var classifications: AttestationClassifications? = null
    private var fileCacheExpiration: Duration = EtsiTrustConfig.DEFAULT_FILE_CACHE_EXPIRATION
    private var cacheTtl: Duration = EtsiTrustConfig.DEFAULT_CACHE_TTL
    private var relaxCertificateProfiles: Boolean = false
    private var pkixRevocationPolicy: PkixRevocationPolicy = PkixRevocationPolicy.CRLPriority
    private var customJwtSignatureVerifier: VerifyJwtSignature? = null
    private var loteConstraints: LoadLoTEAndPointers.Constraints =
        LoadLoTEAndPointers.Constraints.DoNotLoadOtherPointers
    private var loteSignerTrustAnchors: List<X509Certificate> = emptyList()

    /**
     * Sets the LoTE download locations.
     *
     * Example:
     * ```
     * loteLocations(SupportedLists(
     *     pidProviders = Uri("https://trustedlist.../PIDProviders.jwt"),
     *     wrpacProviders = Uri("https://trustedlist.../WRPACProviders.jwt"),
     *     wrprcProviders = Uri("https://trustedlist.../WRPRCProviders.jwt"),
     * ))
     * ```
     *
     * @param locations the supported lists with LoTE URLs
     */
    fun loteLocations(locations: SupportedLists<Uri>) {
        this.loteLocations = locations
    }

    /**
     * Sets the attestation classifications mapping credential types to verification contexts.
     *
     * @param classifications the attestation classifications
     */
    fun classifications(classifications: AttestationClassifications) {
        this.classifications = classifications
    }

    /**
     * Sets the trust anchors of the LoTE signers.
     *
     * A LoTE is trusted only when its signing certificate, the first certificate of its `x5c`
     * header, is one of these certificates or chains to one of them. Not used when
     * [jwtSignatureVerifier] is set.
     *
     * @param certificates the signing certificates of the LoTEs, or the CA certificates that issue them
     */
    fun loteSignerTrustAnchors(vararg certificates: X509Certificate) {
        this.loteSignerTrustAnchors = certificates.toList()
    }

    /**
     * Sets how long downloaded LoTE files are cached on disk.
     *
     * @param duration the file cache expiration duration (default: 24 hours)
     */
    fun fileCacheExpiration(duration: Duration) {
        this.fileCacheExpiration = duration
    }

    /**
     * Sets how long the in-memory trust anchor cache is valid.
     *
     * @param duration the cache TTL duration (default: 20 minutes)
     */
    fun cacheTtl(duration: Duration) {
        this.cacheTtl = duration
    }

    /**
     * Relaxes certificate profile checks for all provider types.
     *
     * When enabled, `endEntityProfile` constraints are stripped from all verification
     * contexts. Use this for DEV/testing environments where certificates may not
     * fully conform to ETSI profile requirements.
     */
    fun relaxCertificateProfiles() {
        this.relaxCertificateProfiles = true
    }

    /**
     * Disables PKIX revocation checking during certificate chain validation.
     *
     * Equivalent to `pkixRevocationPolicy(PkixRevocationPolicy.Disabled)`.
     */
    @Deprecated(
        message = "Use pkixRevocationPolicy(PkixRevocationPolicy.Disabled) instead",
        replaceWith = ReplaceWith("pkixRevocationPolicy(PkixRevocationPolicy.Disabled)")
    )
    fun relaxPkixRevocation() {
        this.pkixRevocationPolicy = PkixRevocationPolicy.Disabled
    }

    /**
     * Sets the PKIX revocation checking policy for certificate chain validation.
     *
     * Controls how CRL and OCSP revocation data is fetched and validated during
     * ETSI LoTE trust anchor provisioning. It applies too when a LoTE signer chains to a CA
     * certificate passed to [loteSignerTrustAnchors].
     *
     * **IMPORTANT**: Only HTTPS CRL/OCSP endpoints are supported. HTTP endpoints are
     * not supported.
     *
     * Available policies:
     * - [PkixRevocationPolicy.Disabled] - No revocation checking
     * - [PkixRevocationPolicy.SoftFail] - CRL only, no OCSP, tolerate network errors
     * - [PkixRevocationPolicy.CRLPriority] - CRL→OCSP fallback (default)
     * - [PkixRevocationPolicy.CRLOnly] - CRL only, no OCSP
     * - [PkixRevocationPolicy.OCSPPriority] - OCSP→CRL fallback (Java default)
     *
     * @param policy the revocation checking policy (default: [PkixRevocationPolicy.CRLPriority])
     */
    fun pkixRevocationPolicy(policy: PkixRevocationPolicy) {
        this.pkixRevocationPolicy = policy
    }

    /**
     * Sets a custom JWT signature verifier for LoTE JWTs.
     *
     * When not set, the core uses its built-in [LoteJwtVerifier] that
     * verifies the LoTE signer against [loteSignerTrustAnchors].
     *
     * @param verifier the custom JWT signature verifier
     */
    fun jwtSignatureVerifier(verifier: VerifyJwtSignature) {
        this.customJwtSignatureVerifier = verifier
    }

    /**
     * Controls whether additional LoTE pointers are followed when loading.
     *
     * @param constraints the LoTE loading constraints
     *   (default: [LoadLoTEAndPointers.Constraints.DoNotLoadOtherPointers])
     */
    fun loteConstraints(constraints: LoadLoTEAndPointers.Constraints) {
        this.loteConstraints = constraints
    }

    /**
     * Builds the [EtsiTrustConfig] from the current builder state.
     *
     * @return a validated [EtsiTrustConfig]
     * @throws IllegalArgumentException if [loteLocations] or [classifications] are not set, or if
     *   neither [loteSignerTrustAnchors] nor [jwtSignatureVerifier] is set
     */
    internal fun build(): EtsiTrustConfig {
        val locations = requireNotNull(loteLocations) {
            "loteLocations must be provided via loteLocations()"
        }
        val cls = requireNotNull(classifications) {
            "classifications must be provided via classifications()"
        }
        require(loteSignerTrustAnchors.isNotEmpty() || customJwtSignatureVerifier != null) {
            "loteSignerTrustAnchors must be provided via loteSignerTrustAnchors()"
        }
        return EtsiTrustConfig(
            loteLocations = locations,
            classifications = cls,
            fileCacheExpiration = fileCacheExpiration,
            cacheTtl = cacheTtl,
            relaxCertificateProfiles = relaxCertificateProfiles,
            pkixRevocationPolicy = pkixRevocationPolicy,
            customJwtSignatureVerifier = customJwtSignatureVerifier,
            loteConstraints = loteConstraints,
            loteSignerTrustAnchors = loteSignerTrustAnchors
        )
    }
}
