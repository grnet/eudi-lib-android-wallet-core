/*
 * Copyright (c) 2023-2025 European Commission
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.europa.ec.eudi.wallet

import android.content.Context
import eu.europa.ec.eudi.iso18013.transfer.TransferManager
import eu.europa.ec.eudi.iso18013.transfer.engagement.BleRetrievalMethod
import eu.europa.ec.eudi.iso18013.transfer.readerauth.ReaderTrustStore
import eu.europa.ec.eudi.iso18013.transfer.response.ReaderAuthPolicy
import eu.europa.ec.eudi.statium.Status
import eu.europa.ec.eudi.wallet.dcapi.DCAPIManager
import eu.europa.ec.eudi.wallet.dcapi.registration.DCAPIRegistration
import eu.europa.ec.eudi.wallet.dcapi.process.isomdoc.IsoMdocDCAPIRequestProcessor
import eu.europa.ec.eudi.wallet.dcapi.process.openid4vp.OpenId4VpDCAPIRequestProcessor
import eu.europa.ec.eudi.wallet.dcapi.registration.DocumentManagerWithDCAPI
import eu.europa.ec.eudi.wallet.dcapi.internal.getDefaultPrivilegedUserAgents
import eu.europa.ec.eudi.wallet.issue.openid4vci.reissue.DocumentManagerWithMetadataCleanup
import eu.europa.ec.eudi.wallet.document.DocumentId
import eu.europa.ec.eudi.wallet.document.DocumentManager
import eu.europa.ec.eudi.wallet.document.IssuedDocument
import eu.europa.ec.eudi.wallet.document.KeyProtectionPolicy
import eu.europa.ec.eudi.wallet.document.KeyProtectionState
import eu.europa.ec.eudi.wallet.document.KeyProtectionUnsupportedException
import eu.europa.ec.eudi.wallet.internal.LogPrinterImpl
import eu.europa.ec.eudi.wallet.internal.i
import eu.europa.ec.eudi.wallet.internal.wrappedWithContentNegotiation
import eu.europa.ec.eudi.wallet.internal.wrappedWithLogging
import eu.europa.ec.eudi.wallet.issue.openid4vci.OpenId4VciManager
import eu.europa.ec.eudi.wallet.logging.Logger
import eu.europa.ec.eudi.wallet.presentation.PresentationManager
import eu.europa.ec.eudi.wallet.presentation.PresentationManagerImpl
import eu.europa.ec.eudi.wallet.provider.WalletAttestationsProvider
import eu.europa.ec.eudi.wallet.provider.WalletKeyManager
import eu.europa.ec.eudi.wallet.statium.DocumentStatusResolver
import eu.europa.ec.eudi.wallet.transactionLogging.DefaultTransactionLogManager
import eu.europa.ec.eudi.wallet.transactionLogging.TransactionLogManager
import eu.europa.ec.eudi.wallet.transactionLogging.TransactionLogger
import eu.europa.ec.eudi.iso18013.transfer.response.WrpRegistrationValidator
import eu.europa.ec.eudi.openid4vci.IssuerMetadataPolicy
import eu.europa.ec.eudi.openid4vp.RegistrationCertificatePolicy
import eu.europa.ec.eudi.wallet.registration.RegistrationTrust
import eu.europa.ec.eudi.wallet.registration.relyingparty.DefaultWrprcAuthenticator
import eu.europa.ec.eudi.wallet.registration.relyingparty.DefaultWrpRegistrationValidator
import eu.europa.ec.eudi.wallet.registration.relyingparty.wrpRegistrationCertificatePolicy
import eu.europa.ec.eudi.wallet.registration.relyingparty.ResolvedWrpRegistration
import eu.europa.ec.eudi.wallet.registration.relyingparty.WrpRegistrationPolicy
import eu.europa.ec.eudi.wallet.registration.issuer.IssuerRegistrationPolicy
import eu.europa.ec.eudi.wallet.trust.EtsiReaderTrustStore
import eu.europa.ec.eudi.wallet.trust.EtsiTrustProvider
import eu.europa.ec.eudi.wallet.trust.IssuerTrustConfigBuilder
import eu.europa.ec.eudi.wallet.trust.ReaderAuthenticationConfigBuilder
import eu.europa.ec.eudi.wallet.statium.DocumentStatusResolverConfigBuilder
import eu.europa.ec.eudi.wallet.transactionLogging.producers.CredentialDeletionLogger
import eu.europa.ec.eudi.wallet.transactionLogging.producers.RegisteredIssuer
import eu.europa.ec.eudi.wallet.transactionLogging.producers.presentation.PresentationLogger
import eu.europa.ec.eudi.wallet.transfer.openId4vp.OpenId4VpManager
import eu.europa.ec.eudi.wallet.transfer.openId4vp.dcql.DcqlRequestProcessor
import eu.europa.ec.eudi.wallet.trustmark.TrustMarkManager
import eu.europa.ec.eudi.wallet.trustmark.TrustMarkSource
import eu.europa.ec.eudi.wallet.issue.openid4vci.reissue.IssuanceMetadata
import io.ktor.client.HttpClient
import kotlinx.coroutines.runBlocking
import org.multipaz.context.initializeApplication
import org.multipaz.securearea.AndroidKeystoreSecureArea
import org.multipaz.securearea.SecureArea
import org.multipaz.securearea.SecureAreaRepository
import org.multipaz.storage.Storage
import org.multipaz.storage.android.AndroidStorage
import java.io.File
import org.multipaz.util.Logger as IdentityLogger

/**
 * The main entry point for interacting with the wallet
 *
 * To create an instance of [EudiWallet], use the [EudiWallet.invoke] method or the [Builder] class.
 *
 * @see [Builder]
 * @see [EudiWallet.invoke]
 *
 * @property config the configuration object
 * @property documentManager the document manager
 * @property presentationManager the presentation manager for both proximity and remote presentation
 * @property transferManager the transfer manager for proximity presentation
 * @property logger the logger
 * @property documentStatusResolver
 */
interface EudiWallet : DocumentManager, PresentationManager, DocumentStatusResolver {

    val config: EudiWalletConfig
    val documentManager: DocumentManager
    val presentationManager: PresentationManager
    val transferManager: TransferManager
    val logger: Logger
    val documentStatusResolver: DocumentStatusResolver

    val walletProvider: WalletAttestationsProvider?
    val walletKeyManager: WalletKeyManager

    /**
     * The protections applied to the keys created with
     * [eu.europa.ec.eudi.wallet.document.DocumentExtensions.getDefaultCreateKeySettings] and
     * [eu.europa.ec.eudi.wallet.document.DocumentExtensions.getDefaultCreateDocumentSettings],
     * determined when the wallet is built from [EudiWalletConfig.configureDocumentKeyCreation] and
     * the device support.
     */
    val keyProtectionState: KeyProtectionState

    /**
     * The transaction-log funnel, if a [TransactionLogger] was configured via the builder.
     * Host-app-triggered transactions (e.g. signing, data-protection actions) should be recorded
     * through this manager so they share the same write path as core-produced entries.
     */
    val transactionLogManager: TransactionLogManager?

    /**
     * The Trust Mark manager, if trust mark data was configured at wallet creation.
     *
     * Provides access to the EUDI Wallet Trust Mark information and resources as defined
     * in EC TS01 v1.2 (2026-06). Supports both [TrustMarkSource.Static] and
     * [TrustMarkSource.Dynamic] configuration. Returns `null` when no [TrustMarkSource]
     * was supplied (e.g. for pre-certification wallets).
     */
    val trustMarkManager: TrustMarkManager?

    /**
     * Creates an instance of [OpenId4VciManager] for the wallet to interact with the OpenID for Verifiable Credential Issuance service.
     *
     * The configuration can be provided in two ways:
     * 1. As a parameter to this method
     * 2. From the wallet's [EudiWalletConfig.openId4VciConfig]
     *
     * @param config Optional specific configuration for this manager instance. If null, the configuration
     *               from [EudiWalletConfig.openId4VciConfig] will be used.
     * @param ktorHttpClientFactory Optional HTTP client factory to use for network requests. If null, the
     *                            wallet's configured HTTP client factory will be used.
     * @return An instance of [OpenId4VciManager]
     * @throws IllegalStateException If neither a config parameter is provided nor a configuration exists in [EudiWalletConfig]
     */
    fun createOpenId4VciManager(
        config: OpenId4VciManager.Config? = null,
        ktorHttpClientFactory: (() -> HttpClient)? = null,
    ): OpenId4VciManager

    /**
     * Resolve the status of the document with the given [documentId]
     *
     * This method will return the status of the document if it is an [IssuedDocument]
     *
     * @param documentId the document ID
     * @return the status of the document
     */
    suspend fun resolveStatusById(documentId: DocumentId): Result<Status> {
        val document = getDocumentById(documentId) as? IssuedDocument
            ?: return Result.failure(IllegalStateException("Document is not an IssuedDocument"))
        return resolveStatus(document)
    }

    companion object {

        private const val TAG = "EudiWallet"

        /**
         * Create an instance of [EudiWallet] with the given configuration and additional configuration
         * using the [Builder] class.
         *
         * Trust Mark information can be supplied via [TrustMarkSource]:
         * - **[TrustMarkSource.Static]**: data compiled into the app at build time.
         * - **[TrustMarkSource.Dynamic]**: data fetched from a backend at runtime via [TrustMarkProvider][eu.europa.ec.eudi.wallet.trustmark.TrustMarkProvider].
         *
         * @param context application context
         * @param config the configuration object
         * @param walletProvider optional provider for Wallet Instance/Unit Attestations
         * @param trustMarkSource optional Trust Mark delivery configuration
         * @param extraConfiguration additional configuration to be applied based on the [Builder]
         */
        operator fun invoke(
            context: Context,
            config: EudiWalletConfig,
            walletProvider: WalletAttestationsProvider? = null,
            trustMarkSource: TrustMarkSource? = null,
            extraConfiguration: (Builder.() -> Unit)? = null,
        ): EudiWallet {
            val builder = Builder(
                context = context,
                config = config,
                walletProvider = walletProvider,
                trustMarkSource = trustMarkSource,
            )
            extraConfiguration?.invoke(builder)
            return builder.build()
        }
    }

    /**
     * Builder class to create an instance of [EudiWallet]
     * @param context application context
     * @param config the configuration object
     *
     * @property config the configuration object
     * @property storage the storage to use for storing/retrieving documents if you want to provide a different implementation
     * @property secureAreas the secure areas to use for documents' keys management if you want to provide a different implementation
     * @property documentManager the document manager to use if you want to provide a custom implementation
     * @property readerTrustStore the reader trust store to use if you want to provide a custom implementation
     * @property presentationManager the presentation manager to use if you want to provide a custom implementation
     * @property logger the logger to use if you want to provide a custom implementation
     * @property ktorHttpClientFactory the Ktor HTTP client factory to use if you want to provide a custom implementation
     * @property transactionLogger the transaction logger to use if you want to provide a custom implementation
     * @property documentStatusResolver the document status resolver to use if you want to provide a custom implementation
     * @property dcapiRegistration the DCAPI registration to use if you want to provide a custom implementation, by default
     * it will be [DefaultDCAPIRegistration] when the DCAPI is enabled in the configuration
     */
    class Builder(
        context: Context,
        val config: EudiWalletConfig,
        val walletProvider: WalletAttestationsProvider?,
        val trustMarkSource: TrustMarkSource? = null,
    ) {
        private val context = context.applicationContext
        var storage: Storage? = null
        var secureAreas: List<SecureArea>? = null
        var documentManager: DocumentManager? = null
        var presentationManager: PresentationManager? = null
        var logger: Logger? = null
        var ktorHttpClientFactory: (() -> HttpClient)? = null
        var transactionLogger: TransactionLogger? = null
        var documentStatusResolver: DocumentStatusResolver? = null
        var dcapiRegistration: DCAPIRegistration? = null

        var walletKeyManager: WalletKeyManager? = null

        /**
         * Configure with the given [SecureArea] implementations to use for documents' keys management.
         * If not set, the default secure area will be used which is [AndroidKeystoreSecureArea].
         *
         * @param secureAreas the secure areas
         * @return this [Builder] instance
         */
        fun withSecureAreas(secureAreas: List<SecureArea>) = apply {
            this.secureAreas = secureAreas
        }

        /**
         * Configure with the given [Storage] to use for storing/retrieving documents.
         * If not set, the default storage will be used which is [AndroidStorage].
         *
         * @param storage the storage
         * @return this [Builder] instance
         */
        fun withStorage(storage: Storage) = apply {
            this.storage = storage
        }

        /**
         * Configure with the given [DocumentManager] to use. If not set, the default document manager
         * will be used which is [DocumentManagerImpl] configured with the provided [storageEngine] and [secureAreas]
         * if they are set.
         *
         * @param documentManager the document manager
         * @return this [Builder] instance
         */
        fun withDocumentManager(documentManager: DocumentManager) =
            apply { this.documentManager = documentManager }

        /**
         * Configure with the given [PresentationManager] to use for both proximity and remote presentation.
         * If not set, the default presentation manager will be used which is [PresentationManagerImpl]
         * that uses the [eu.europa.ec.eudi.iso18013.transfer.TransferManagerImpl] for proximity presentation
         * and [OpenId4VpManager] for remote presentation.
         *
         * @param presentationManager the presentation manager
         * @return this [Builder] instance
         */
        fun withPresentationManager(presentationManager: PresentationManager) =
            apply { this.presentationManager = presentationManager }

        /**
         * Configure with the given [Logger] to use for logging. If not set, the default logger will be used
         * which is configured with the [EudiWalletConfig.configureLogging].
         *
         * @param logger the logger
         * @return this [Builder] instance
         */
        fun withLogger(logger: Logger) = apply { this.logger = logger }

        /**
         * Configure with the given Ktor HTTP client factory to use for making HTTP requests.
         * Ktor HTTP client is used by the [OpenId4VpManager] and [OpenId4VciManager] for making HTTP requests.
         *
         * If not set, the default Ktor HTTP client factory will be used which is initialized with the default
         *
         * @param ktorHttpClientFactory the Ktor HTTP client factory
         * @return this [Builder] instance
         */
        fun withKtorHttpClientFactory(ktorHttpClientFactory: () -> HttpClient) = apply {
            this.ktorHttpClientFactory = ktorHttpClientFactory
        }


        /**
         * Configure with the given [TransactionLogger] to use for logging transactions.
         * If not set, the default transaction logger will be used which logs transactions to the console.
         *
         * @param transactionLogger the transaction logger
         * @return this [Builder] instance
         */
        fun withTransactionLogger(transactionLogger: TransactionLogger) = apply {
            this.transactionLogger = transactionLogger
        }

        /**
         * Configure with the given [DocumentStatusResolver] to use for resolving the status of documents.
         * If not set, the default document status resolver will be used which is
         * [eu.europa.ec.eudi.wallet.statium.DocumentStatusResolverImpl] that uses the [HttpClient] provided in the configuration.
         *
         * @param documentStatusResolver the document status resolver
         * @return this [Builder] instance
         */
        fun withDocumentStatusResolver(documentStatusResolver: DocumentStatusResolver) = apply {
            this.documentStatusResolver = documentStatusResolver
        }

        /**
         * Configure with the given [DCAPIRegistration] to use for registering credentials
         * with the Digital Credential API (DCAPI).
         * If not set, the default [DefaultDCAPIRegistration] will be used when the DCAPI is enabled
         * in the configuration.
         *
         * @param dcapiRegistration the DCAPI registration
         * @return this [Builder] instance
         */
        fun withDCAPIRegistration(dcapiRegistration: DCAPIRegistration) = apply {
            this.dcapiRegistration = dcapiRegistration
        }

        fun withWalletKeyManager(walletKeyManager: WalletKeyManager): Builder = apply {
            this.walletKeyManager = walletKeyManager
        }

        /**
         * Build the [EudiWallet] instance
         *
         * The [EudiWallet] instance will be created based on the configuration provided in the [Builder] class.
         *
         * The [EudiWallet] instance will be created with the following default implementations if not set:
         * - [AndroidStorage] for storing/retrieving documents
         * - [AndroidKeystoreSecureArea] for managing documents' keys
         * - [DocumentManagerImpl] for managing documents
         * - [PresentationManagerImpl] for both proximity and remote presentation
         * - [OpenId4VpManager] for remote presentation
         * - [eu.europa.ec.eudi.iso18013.transfer.TransferManagerImpl] for proximity presentation
         * - [eu.europa.ec.eudi.wallet.statium.DocumentStatusResolverImpl] for resolving the status of documents
         *
         * **Note**: The [EudiWalletConfig.documentsStoragePath] is not set, the default storage path
         * will be used which is the application's no backup files directory.
         *
         * **Note**: With [KeyProtectionPolicy.Required] in [EudiWalletConfig.configureDocumentKeyCreation],
         * building fails with [KeyProtectionUnsupportedException] if the device is not secured with a PIN,
         * pattern or password (user authentication) or does not support StrongBox.
         * With [KeyProtectionPolicy.IfSupported], the keys are created without
         * the protection that the device does not support. The protections that apply are in
         * [EudiWallet.keyProtectionState]; the configuration is not changed.
         *
         * @return [EudiWallet]
         */
        fun build(): EudiWallet {

            val loggerToUse = (this@Builder.logger ?: Logger(config)).also {
                IdentityLogger.logPrinter = LogPrinterImpl(it)
            }
            initializeApplication(context.applicationContext)
            val keyProtectionState = KeyProtectionState(
                userAuthenticationRequired = resolveUserAuthentication(loggerToUse),
                useStrongBox = resolveStrongBox(loggerToUse),
            )

            // Build ETSI trust provider if configured
            val etsiTrustProvider = config.etsiTrustConfig?.let {
                EtsiTrustProvider(
                    config = it,
                    context = context,
                    logger = loggerToUse,
                    ktorHttpClientFactory = ktorHttpClientFactory,
                )
            }
            val etsiSource = etsiTrustProvider?.isChainTrusted
            val etsiClassifications = config.etsiTrustConfig?.classifications

            // Resolve deferred issuer trust config; null only when turned off with doNotVerify()
            config.issuerTrustConfig = IssuerTrustConfigBuilder()
                .apply(config.issuerTrustBlock ?: {})
                .build(etsiSource, etsiClassifications, loggerToUse)

            // Trust for the credential issuer's registration certificate and for the status list that
            // carries its revocation status. Both ETSI verification contexts cover an issuer as well as
            // a verifier, so the same trusted lists serve the issuance and the presentation path.
            // Certificates configured with configureIssuerRegistrationTrust take precedence for both
            // signers. The certificate is carried in the signed issuer metadata, so the trust is needed
            // only when signed metadata is required.
            val issuerRegistrationTrust = RegistrationTrust.forIssuer(config, etsiSource, loggerToUse)
            if (config.issuerRegistrationPolicy == IssuerRegistrationPolicy.Enabled &&
                config.issuerTrustConfig?.issuerMetadataPolicy is IssuerMetadataPolicy.RequireSigned
            ) {
                requireNotNull(issuerRegistrationTrust.certificateTrust) {
                    "IssuerRegistrationPolicy.Enabled with signed issuer metadata requires trust for issuer " +
                        "registration certificates. Call configureIssuerRegistrationTrust() or " +
                        "configureEtsiTrust(), or configureIssuerRegistrationPolicy(IssuerRegistrationPolicy.Disabled) " +
                        "to opt out."
                }
            }

            // Resolve deferred status resolver config
            config.statusResolverBlock?.let { block ->
                val builder = DocumentStatusResolverConfigBuilder().apply(block)
                config.documentStatusResolverClockSkew = builder.clockSkew
                config.statusListTrustConfig = builder.buildTrustConfig(etsiSource, etsiClassifications)
            }

            // Create shared issuance metadata storage (used by both the wrapper and OpenId4VciManager)
            val issuanceMetadataStorage = config.openId4VciConfig?.issuanceMetadataStorage ?: run {
                val storagePath = File(
                    context.noBackupFilesDir,
                    "issuance_metadata.db"
                ).absolutePath
                AndroidStorage(storagePath)
            }

            val documentManagerToUse =
                (documentManager ?: getDefaultDocumentManager(storage, secureAreas))
                    .let { manager ->
                        DocumentManagerWithMetadataCleanup(
                            delegate = manager,
                            issuanceMetadataStorage = issuanceMetadataStorage,
                            logger = loggerToUse
                        )
                    }
                    .let { manager ->
                        val dcapiCfg = config.dcapiConfig
                        if (dcapiCfg?.enabled == true) {
                            DocumentManagerWithDCAPI(
                                delegate = manager,
                                dcapiRegistration = dcapiRegistration,
                                supportedProtocols = dcapiCfg.supportedProtocols.toList(),
                                logger = loggerToUse,
                                credentialTitles = dcapiCfg.credentialTitles,
                            )
                        } else manager
                    }

            // --- Build ReaderAuthPolicy (single policy for both transports) ---
            val readerAuthPolicy: ReaderAuthPolicy = ReaderAuthenticationConfigBuilder()
                .apply(config.readerAuthenticationBlock ?: {})
                .build(etsiSource = etsiSource, logger = loggerToUse)

            // Derive trust store for components not yet migrated to ReaderAuthPolicy
            val readerTrustStoreToUse = readerAuthPolicy.readerTrustStore?.also {
                if (it is EtsiReaderTrustStore) it.logger = loggerToUse
            }

            // Registration certificate handling shared by every transport: the wallet authenticates
            // and evaluates the certificate on the proximity and DC-API paths, and supplies the same
            // evaluation to the OpenID4VP library through a RegistrationCertificatePolicy on the remote
            // path. When ETSI trust is available, the signer chain is checked against the WRPRC
            // (WalletRelyingPartyRegistrationCertificate) context — distinct from the WRPAC context
            // used for reader authentication — and the status list signer against the registration
            // certificate status context (WalletRelyingPartyRegistrationCertificateStatus).
            // Certificates configured with configureWrpRegistrationTrust take precedence for both
            // signers. The reader trust store is not used, so an access certificate authority cannot
            // vouch for a registration certificate.
            val wrpRegistrationValidator: DefaultWrpRegistrationValidator?
            val registrationCertificatePolicy: RegistrationCertificatePolicy?
            val resolvedRegistration: ResolvedWrpRegistration?

            if (config.wrpRegistrationPolicy == WrpRegistrationPolicy.Disabled) {
                wrpRegistrationValidator = null
                registrationCertificatePolicy = null
                resolvedRegistration = null
            } else {
                val registrationTrust = RegistrationTrust.forRelyingParty(config, etsiSource, loggerToUse)
                val certificateTrust = requireNotNull(registrationTrust.certificateTrust) {
                    "WrpRegistrationPolicy.Enabled requires trust for relying party registration certificates. " +
                        "Call configureWrpRegistrationTrust() or configureEtsiTrust(), or " +
                        "configureWrpRegistrationPolicy(WrpRegistrationPolicy.Disabled) to opt out."
                }
                val evaluator = registrationTrust.wrpRegistrationEvaluator(
                    custom = config.wrpRegistrationEvaluator,
                    logger = loggerToUse,
                    httpClientFactory = ktorHttpClientFactory,
                )
                val authenticator = DefaultWrprcAuthenticator(certificateTrust, loggerToUse)
                wrpRegistrationValidator = DefaultWrpRegistrationValidator(authenticator, evaluator)
                // The library policy and the request processor evaluate the same certificate for a
                // request, one after the other; the first evaluation is held for the second to reuse.
                resolvedRegistration = ResolvedWrpRegistration()
                registrationCertificatePolicy =
                    wrpRegistrationCertificatePolicy(authenticator, evaluator, resolvedRegistration, loggerToUse)
            }

            val transferManager = getTransferManager(
                documentManager = documentManagerToUse,
                readerAuthPolicy = readerAuthPolicy,
                wrpRegistrationValidator = wrpRegistrationValidator
            )

            // Single funnel for all transaction-log entries, created from the configured storage SPI.
            val transactionLogManagerToUse = transactionLogger?.let {
                DefaultTransactionLogManager(storage = it)
            }

            val presentationManagerToUse = presentationManager ?: getDefaultPresentationManager(
                documentManager = documentManagerToUse,
                transferManager = transferManager,
                readerAuthPolicy = readerAuthPolicy,
                readerTrustStore = readerTrustStoreToUse,
                registrationValidator = wrpRegistrationValidator,
                registrationCertificatePolicy = registrationCertificatePolicy,
                resolvedRegistration = resolvedRegistration,
                loggerObj = loggerToUse
            ).wrapWithTrasactionLogger(documentManagerToUse, transactionLogManagerToUse, loggerToUse)

            val documentStatusResolverToUse = getDocumentStatusResolver(loggerToUse)

            val trustMarkManagerToUse = trustMarkSource?.let { source ->
                val httpFactory = (ktorHttpClientFactory ?: { HttpClient() })
                    .wrappedWithLogging(loggerToUse)
                    .wrappedWithContentNegotiation()
                TrustMarkManager(
                    source = source,
                    ktorHttpClientFactory = httpFactory,
                    logger = loggerToUse,
                )
            }

            return EudiWalletImpl(
                context = context,
                config = config,
                documentManager = documentManagerToUse.wrapWithDeletionLogger(
                    transactionLogManagerToUse,
                    loggerToUse,
                    issuanceMetadataStorage
                ),
                presentationManager = presentationManagerToUse,
                transferManager = transferManager,
                walletProvider = walletProvider,
                walletKeyManager = walletKeyManager ?: WalletKeyManager.getDefault(context),
                keyProtectionState = keyProtectionState,
                logger = loggerToUse,
                documentStatusResolver = documentStatusResolverToUse,
                transactionLogManager = transactionLogManagerToUse,
                trustMarkManager = trustMarkManagerToUse,
                ktorHttpClientFactory = ktorHttpClientFactory,
                issuanceMetadataStorage = issuanceMetadataStorage,
                issuerRegistrationTrust = issuerRegistrationTrust
            )
        }

        /**
         * Get the default [PresentationManagerImpl] instance based on the [DocumentManager] and [TransferManager] implementations
         * @param documentManager the document manager
         * @param transferManager the transfer manager
         * @param readerAuthPolicy the reader authentication policy (embeds the trust store)
         * @param readerTrustStore the reader trust store (derived from policy, for components not yet migrated)
         * @return the default [PresentationManagerImpl] instance
         */
        @JvmSynthetic
        internal fun getDefaultPresentationManager(
            documentManager: DocumentManager,
            transferManager: TransferManager,
            readerAuthPolicy: ReaderAuthPolicy,
            readerTrustStore: ReaderTrustStore?,
            loggerObj: Logger,
            registrationValidator: DefaultWrpRegistrationValidator? = null,
            registrationCertificatePolicy: RegistrationCertificatePolicy? = null,
            resolvedRegistration: ResolvedWrpRegistration? = null,
        ): PresentationManagerImpl {
            val openId4vpManager = config.openId4VpConfig?.let { openId4VpConfig ->
                OpenId4VpManager(
                    config = openId4VpConfig,
                    requestProcessor = DcqlRequestProcessor(
                        documentManager = documentManager,
                        readerTrustStore = readerTrustStore,
                        readerAuthPolicy = readerAuthPolicy,
                        logger = loggerObj,
                        transactionDataTypes = openId4VpConfig.transactionDataTypes
                    ).apply {
                        wrpRegistrationValidator = registrationValidator
                        this.resolvedRegistration = resolvedRegistration
                    },
                    logger = loggerObj,
                    ktorHttpClientFactory = ktorHttpClientFactory,
                    registrationCertificatePolicy = registrationCertificatePolicy
                ).apply { this.resolvedRegistration = resolvedRegistration }
            }
            val dcapiManager = config.dcapiConfig?.takeIf { it.enabled }?.let { dcapiConfig ->
                val privilegedAllowlist =
                    dcapiConfig.privilegedAllowlist ?: context.getDefaultPrivilegedUserAgents()

                val supportedProtocols = dcapiConfig.supportedProtocols.toList()
                val openId4VpSupported = supportedProtocols.filter { it.isOpenId4Vp }

                // OpenID4VP-over-DC-API processor, only when at least one OpenID4VP protocol is enabled.
                val openId4VpDcApiProcessor = config.openId4VpConfig
                    ?.takeIf { openId4VpSupported.isNotEmpty() }
                    ?.let { openId4VpConfig ->
                        OpenId4VpDCAPIRequestProcessor(
                            openId4VpConfig = openId4VpConfig,
                            dcqlRequestProcessor = DcqlRequestProcessor(
                                documentManager = documentManager,
                                readerTrustStore = readerTrustStore,
                                readerAuthPolicy = readerAuthPolicy,
                                transactionDataTypes = openId4VpConfig.transactionDataTypes
                            ).apply {
                                wrpRegistrationValidator = registrationValidator
                                this.resolvedRegistration = resolvedRegistration
                            },
                            privilegedAllowlist = privilegedAllowlist,
                            supportedProtocols = openId4VpSupported,
                            logger = loggerObj,
                            registrationCertificatePolicy = registrationCertificatePolicy,
                        ).apply { this.resolvedRegistration = resolvedRegistration }
                    }
                DCAPIManager(
                    isoMdocRequestProcessor = IsoMdocDCAPIRequestProcessor(
                        documentManager = documentManager,
                        readerAuthPolicy = readerAuthPolicy,
                        privilegedAllowlist = privilegedAllowlist,
                        zkSystemRepository = config.zkSystemRepository,
                        zkResponsePolicy = config.zkResponsePolicy,
                        wrpRegistrationValidator = registrationValidator,
                        logger = loggerObj
                    ),
                    supportedProtocols = supportedProtocols,
                    openId4VpRequestProcessor = openId4VpDcApiProcessor,
                    logger = loggerObj
                )
            }
            return PresentationManagerImpl(
                transferManager = transferManager,
                openId4vpManager = openId4vpManager,
                dcapiManager = dcapiManager,
                nfcEngagementServiceClass = config.nfcEngagementServiceClass
            )
        }

        @get:JvmSynthetic
        internal val defaultStoragePath: String
            get() = File(
                context.noBackupFilesDir.path,
                "${config.documentManagerIdentifier}.db"
            ).absolutePath

        /**
         * Get the default [Storage] instance based on the configuration
         * @return the default [Storage] instance
         * @throws IllegalStateException if [EudiWalletConfig.documentsStoragePath] is not set
         */
        @get:JvmSynthetic
        internal val defaultStorage: Storage
            get() {
                val documentsStoragePathToUse = config.documentsStoragePath
                    ?: defaultStoragePath
                return AndroidStorage(
                    databasePath = documentsStoragePathToUse
                )
            }

        /**
         * Get the default [SecureArea] instance based on the [Storage]
         * @param storage the storage
         * @return the default [SecureArea] instance
         */
        @JvmSynthetic
        internal fun getDefaultSecureArea(storage: Storage): SecureArea {
            return runBlocking { AndroidKeystoreSecureArea.create(storage) }
        }

        /**
         * Get the default [DocumentManager] instance based on the [Storage] and [SecureArea] implementations
         * @param storage the storage
         * @param secureAreas the secure areas
         * @return the default [DocumentManager] instance
         */
        @JvmSynthetic
        internal fun getDefaultDocumentManager(
            storage: Storage? = null,
            secureAreas: List<SecureArea>? = null,
        ): DocumentManager {
            val storageToUse = storage ?: defaultStorage
            val secureAreaRepository = SecureAreaRepository.Builder().apply {
                secureAreas?.forEach { add(it) }
                    ?: add(getDefaultSecureArea(storageToUse))
            }.build()

            return DocumentManager {
                setStorage(storageToUse)
                setSecureAreaRepository(secureAreaRepository)
                setIdentifier(config.documentManagerIdentifier)
            }
        }

        /**
         * Get the default [TransferManager] instance based on the [DocumentManager] and [ReaderAuthPolicy]
         * @param documentManager the document manager
         * @param readerAuthPolicy the reader authentication policy (embeds the trust store)
         * @return the default [TransferManager] instance
         */
        @JvmSynthetic
        internal fun getTransferManager(
            documentManager: DocumentManager,
            readerAuthPolicy: ReaderAuthPolicy,
            wrpRegistrationValidator: WrpRegistrationValidator? = null
        ) = TransferManager.getDefault(
            context = context,
            documentManager = documentManager,
            readerAuthPolicy = readerAuthPolicy,
            retrievalMethods = listOf(
                BleRetrievalMethod(
                    peripheralServerMode = config.enableBlePeripheralMode,
                    centralClientMode = config.enableBleCentralMode,
                    clearBleCache = config.clearBleCache
                )
            ),
            zkSystemRepository = config.zkSystemRepository,
            zkResponsePolicy = config.zkResponsePolicy,
            wrpRegistrationValidator = wrpRegistrationValidator
        )

        /**
         * Get the default [DocumentStatusResolver] instance based on the configuration if not set
         *
         * @return the [DocumentStatusResolver] instance
         */
        @JvmSynthetic
        internal fun getDocumentStatusResolver(logger: Logger): DocumentStatusResolver {
            return documentStatusResolver ?: DocumentStatusResolver {
                ktorHttpClientFactory?.let { withKtorHttpClientFactory(it) }
                withAllowedClockSkew(config.documentStatusResolverClockSkew)
                config.statusListTrustConfig?.let { withStatusListTrustConfig(it) }
                withLogger(logger)
            }
        }

        /**
         * Returns the capabilities of the Android Keystore Secure Area
         */
        @get:JvmSynthetic
        internal val capabilities: AndroidKeystoreSecureArea.Capabilities by lazy {
            AndroidKeystoreSecureArea.Capabilities()
        }

        /**
         * Resolve whether the document keys require user authentication, from
         * [EudiWalletConfig.userAuthenticationPolicy] and whether the device is secured with a PIN,
         * pattern or password.
         *
         * @throws KeyProtectionUnsupportedException if the policy is [KeyProtectionPolicy.Required] and the device is not secured
         */
        @JvmSynthetic
        internal fun resolveUserAuthentication(loggerObj: Logger): Boolean =
            when (config.userAuthenticationPolicy) {
                KeyProtectionPolicy.Required -> {
                    if (!capabilities.secureLockScreenSetup) {
                        throw KeyProtectionUnsupportedException(
                            protection = KeyProtectionUnsupportedException.Protection.UserAuthentication,
                            message = "User authentication is required for document keys but the device is not secured " +
                                "with a PIN, pattern or password. Ask the user to set up a screen lock, or use " +
                                "KeyProtectionPolicy.IfSupported or KeyProtectionPolicy.Disabled in " +
                                "configureDocumentKeyCreation() to create the keys without it."
                        )
                    }
                    true
                }

                KeyProtectionPolicy.IfSupported -> capabilities.secureLockScreenSetup.also { supported ->
                    if (!supported) {
                        loggerObj.i(
                            TAG,
                            "The device is not secured with a PIN, pattern or password. " +
                                "Document keys are created without user authentication."
                        )
                    }
                }

                KeyProtectionPolicy.Disabled -> false
            }

        /**
         * Resolve whether the document keys are created in StrongBox, from
         * [EudiWalletConfig.strongBoxPolicy] and whether the device supports StrongBox.
         *
         * @throws KeyProtectionUnsupportedException if the policy is [KeyProtectionPolicy.Required] and the device does not support StrongBox
         */
        @JvmSynthetic
        internal fun resolveStrongBox(loggerObj: Logger): Boolean =
            when (config.strongBoxPolicy) {
                KeyProtectionPolicy.Required -> {
                    if (!capabilities.strongBoxSupported) {
                        throw KeyProtectionUnsupportedException(
                            protection = KeyProtectionUnsupportedException.Protection.StrongBox,
                            message = "StrongBox is required for document keys but the device does not support it. " +
                                "Use KeyProtectionPolicy.IfSupported or KeyProtectionPolicy.Disabled " +
                                "in configureDocumentKeyCreation() to create the keys without it.",
                        )
                    }
                    true
                }

                KeyProtectionPolicy.IfSupported -> capabilities.strongBoxSupported.also { supported ->
                    if (!supported) {
                        loggerObj.i(TAG, "StrongBox is not supported on this device. Document keys are created without it.")
                    }
                }

                KeyProtectionPolicy.Disabled -> false
            }

        /**
         * Wrap the [PresentationManager] with a transaction logger
         *
         * @receiver [PresentationManager]
         * @param documentManager the document manager
         * @param transactionLogManager the transaction-log funnel, or null if logging is disabled
         * @return [PresentationManager] wrapped with a transaction logger
         */
        internal fun PresentationManager.wrapWithTrasactionLogger(
            documentManager: DocumentManager,
            transactionLogManager: TransactionLogManager?,
            loggerObj: Logger,
        ): PresentationManager {
            return transactionLogManager?.let { manager ->
                PresentationLogger(
                    delegate = this,
                    transactionLogManager = manager,
                    logger = loggerObj,
                )
            } ?: this
        }

        /**
         * Wraps the [DocumentManager] with a decorator that logs credential-deletion transactions
         * (TS10 §3.6). Returns the receiver unchanged when [transactionLogManager] is null
         * (logging disabled).
         *
         * @param transactionLogManager the transaction-log funnel, or null if logging is disabled
         * @param loggerObj the logger for internal diagnostics
         * @param issuanceMetadataStorage where the issuer's registered details were kept at issuance,
         *   so the deletion entry can name the issuer (TS10 §3.6)
         * @return [DocumentManager] wrapped with a deletion logger
         */
        internal fun DocumentManager.wrapWithDeletionLogger(
            transactionLogManager: TransactionLogManager?,
            loggerObj: Logger,
            issuanceMetadataStorage: Storage,
        ): DocumentManager {
            return transactionLogManager?.let { manager ->
                CredentialDeletionLogger(
                    delegate = this,
                    transactionLogManager = manager,
                    logger = loggerObj,
                    registeredIssuerResolver = { documentId ->
                        runBlocking {
                            issuanceMetadataStorage.getTable(IssuanceMetadata.STORAGE_TABLE_SPEC)
                                .get(documentId)
                                ?.let { IssuanceMetadata.fromByteArray(it.toByteArray()) }
                                ?.let { RegisteredIssuer(it.issuerIdentifier, it.issuerName) }
                        }
                    },
                )
            } ?: this
        }

    }
}

