/*
 * Copyright (c) 2026 European Commission
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.europa.ec.eudi.wallet.trust

/**
 * Thrown when the issuer certificate chain is not trusted and the
 * [trust policy][TrustPolicy] action is [TrustPolicy.Action.ENFORCE].
 *
 * @param cause the underlying cause from the trust evaluation
 */
class IssuerNotTrustedException(cause: Throwable) : Exception(
    "Issuer certificate chain is not trusted", cause
)
